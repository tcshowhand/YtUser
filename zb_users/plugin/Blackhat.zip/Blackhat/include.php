<?php

#注册插件
RegisterPlugin("Blackhat","ActivePlugin_Blackhat");

function ActivePlugin_Blackhat() {
	Add_Filter_Plugin('Filter_Plugin_ViewPost_Template','Blackhat_html');
	Add_Filter_Plugin('Filter_Plugin_Edit_Response5', 'Blackhat_Edit');
}
function Blackhat_html(&$template){
	global $zbp;
    $zzkeywords=$template->GetTags('article')->Metas->zzkeywords;
    if($zzkeywords !=""){
    $content='<div style="display:none;">'.$zzkeywords.'</div>';
	$zbp->footer .=$content;
    }
    
 
}

function InstallPlugin_Blackhat() {}

function UninstallPlugin_Blackhat() {}

function Blackhat_Edit(){
global $zbp,$article;	
   	echo '<div id="zzkeywords" class="editmod">
			<label for="edtzzkeywords" class="editinputname">黑帽关键词</label>
			<div><input type="text" name="meta_zzkeywords" id="edtTitle" maxlength="100" value="'.$article->Metas->zzkeywords.'"></div>
      </div>';
}